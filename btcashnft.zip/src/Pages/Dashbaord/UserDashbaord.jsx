import React from 'react'
import Layout from '../../components/Dashboard/UserDashbaord/Layout'

const UserDashbaord = () => {
  return (
   <Layout/>
  )
}

export default UserDashbaord